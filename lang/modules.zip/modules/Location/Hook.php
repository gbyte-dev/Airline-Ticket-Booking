<?php
namespace Modules\Location;

class Hook
{
    const FORM_AFTER_TRIP_IDEA = 'location_form_after_trip_idea';
    const BEFORE_SAVING = 'location_before_saving';
    const AFTER_SAVING = 'location_after_saving';
    const AFTER_MAP = 'location_after_map';
}
