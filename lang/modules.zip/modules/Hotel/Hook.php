<?php


namespace Modules\Hotel;


class Hook
{
    const FORM_AFTER_POLICY = 'hotel_form_after_policy';
    const AFTER_SAVING = 'hotel_after_saving';
    const HOTEL_SETTING_CONFIG = 'hotel_setting_config';
    const HOTEL_SETTING_AFTER_MAP = 'hotel_setting_after_map';
    const HOTEL_SETTING_AFTER_LAYOUT_SEARCH = 'hotel_setting_layout_detail';

}
