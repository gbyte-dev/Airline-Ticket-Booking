<div class="modal fade" tabindex="-1" role="dialog" id="image_thumb_modal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-body">
                <div class="image_show_full w-100"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{__('Close')}}</button>
                </button>
            </div>
        </div>
    </div>
</div>
