<?php

namespace Modules\Flight\Controllers;

use App\Http\Controllers\Controller;
use Modules\Flight\Models\SeatType;
use Modules\Location\Models\LocationCategory;
use Modules\Flight\Models\Subscription;
use Illuminate\Http\Request;
use Modules\Location\Models\Location;
use Modules\Review\Models\Review;
use Modules\Core\Models\Attributes;
use DB;
use Illuminate\Support\Facades\Crypt;
use Cookie;
use Session;

class SubscriptionController extends Controller
{
    public function index(Request $request){

        Subscription::create([
            'email' => $request->email,
            'phone' => $request->phone,
        ]);

        return redirect()->back()->with('success', 'You have successfully subscribed!');
    }
     
    public function show(){
        $data = Subscription::all();
        return view('flight::admin.subscribe.subscribe',compact('data'));
    }

}
