@extends('admin.layouts.app')

@section('content')
    <div class="container-fluid">
    <h3>Leads Costumers</h3>
    <div class="panel">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        {{-- <th>Random_ID</th> --}}
                        <th>Passenger Name
                          </th>
                        <th>Phone</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Flight Date</th>
                        <th>Flight Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($leads as $booking)
                        <tr>
                            {{-- <td>{{ $loop->iteration }}</td> --}}
                            {{-- <td>{{ \Carbon\Carbon::parse($booking->created_at)->format('d/m/Y') }}</td> --}}
                            {{-- <td >{{ $booking->random_id }}</td> --}}
                            <td style="color: #08f;">{{ $booking->first_name }}
                               {{ $booking->last_name }}</td>
                            <td>{{ $booking->phone }}</td>
                            <td>{{ $booking->from }}</td>
                            <td>{{ $booking->to}}</td>
                            <td>{{ $booking->on_date}}</td>
                            <td>{{ ($booking->flight_type=='return')?'round trip':'one-way'}}</td>
                            
                            <td>
                                <a href="{{ route('flight.admin.booking.showleads', $booking->id) }}"
                                    class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            {{-- <div style="float:right;">{{ $bookings->links() }}</div> --}}
        </div>
    </div>
</div>
@endsection
{{-- <script>
    function updateStatus(status) {
        const bookingId = {{ $booking->id }};
        alert(bookingId);
        // Pass the booking ID to the function

        // Make an AJAX call to update the status in the database
        fetch(`{{ route('flight.admin.booking.update.status', $booking->id) }}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token for security
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                // Show alert message based on response
                alert(data.message);
            })
            .catch(error => {
                console.error('Error:', error);
                alert('There was an error updating the status.');
            });
    }</script> --}}
