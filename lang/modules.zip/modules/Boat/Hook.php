<?php


namespace Modules\Boat;


class Hook
{
    const BOAT_SETTING_CONFIG = 'boat_setting_config';
}
