<?php
if(is_enable_language_route())
    include 'web.php';
