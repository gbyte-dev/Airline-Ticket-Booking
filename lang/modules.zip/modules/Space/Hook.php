<?php


namespace Modules\Space;


class Hook
{
    const SPACE_SETTING_CONFIG = 'space_setting_config';
    const SPACE_SETTING_AFTER_MAP = 'space_setting_after_map';
    const SPACE_SETTING_AFTER_LAYOUT_SEARCH = 'space_setting_layout_detail';

}
